<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_categoria = $_GET['id'];
$mensaje = "";

// Obtener categoría
$stmt = $pdo->prepare("SELECT * FROM categorias WHERE id_categoria = ?");
$stmt->execute([$id_categoria]);
$categoria = $stmt->fetch();

if (!$categoria) {
    die("Categoría no encontrada.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_categoria'];
    $descripcion = $_POST['descripcion'];

    try {
        $stmt = $pdo->prepare("UPDATE categorias SET nombre_categoria=?, descripcion=? WHERE id_categoria=?");
        $stmt->execute([$nombre, $descripcion, $id_categoria]);
        header("Location: listar.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al actualizar categoría: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Categoría</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Editar Categoría</h1>
    <?php if($mensaje): ?>
        <p style="color:red;"><?= $mensaje ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Nombre Categoría:</label>
        <input type="text" name="nombre_categoria" value="<?= htmlspecialchars($categoria['nombre_categoria']) ?>" required>
        <label>Descripción:</label>
        <textarea name="descripcion"><?= htmlspecialchars($categoria['descripcion']) ?></textarea>
        <button type="submit">Actualizar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
