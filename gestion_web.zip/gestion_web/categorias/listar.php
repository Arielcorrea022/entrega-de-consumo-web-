<?php
session_start();
require_once "../config.php";

if (!isset($_SESSION['cedula'])) {
    header("Location: ../index.php");
    exit;
}

// Obtener categorías
$stmt = $pdo->query("SELECT * FROM categorias ORDER BY nombre_categoria ASC");
$categorias = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Categorías</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Lista de Categorías</h1>
    <a href="agregar.php">Agregar Categoría</a>
    <a href="../dashboard.php">Volver al Dashboard</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Acciones</th>
        </tr>
        <?php foreach($categorias as $c): ?>
        <tr>
            <td><?= $c['id_categoria'] ?></td>
            <td><?= htmlspecialchars($c['nombre_categoria']) ?></td>
            <td><?= htmlspecialchars($c['descripcion']) ?></td>
            <td>
                <a href="editar.php?id=<?= $c['id_categoria'] ?>">Editar</a> |
                <a href="eliminar.php?id=<?= $c['id_categoria'] ?>" onclick="return confirm('¿Eliminar categoría?')">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
