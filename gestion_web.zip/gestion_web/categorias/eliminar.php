<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_categoria = $_GET['id'];

try {
    $stmt = $pdo->prepare("DELETE FROM categorias WHERE id_categoria = ?");
    $stmt->execute([$id_categoria]);
    header("Location: listar.php");
    exit;
} catch(PDOException $e) {
    die("Error al eliminar categoría: " . $e->getMessage());
}
?>
