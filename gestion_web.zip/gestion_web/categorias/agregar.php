<?php
session_start();
require_once "../config.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_categoria'];
    $descripcion = $_POST['descripcion'];

    try {
        $stmt = $pdo->prepare("INSERT INTO categorias (nombre_categoria, descripcion) VALUES (?, ?)");
        $stmt->execute([$nombre, $descripcion]);
        header("Location: listar.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al agregar categoría: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Categoría</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Agregar Categoría</h1>
    <?php if($mensaje): ?>
        <p style="color:red;"><?= $mensaje ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Nombre Categoría:</label>
        <input type="text" name="nombre_categoria" required>
        <label>Descripción:</label>
        <textarea name="descripcion"></textarea>
        <button type="submit">Agregar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
