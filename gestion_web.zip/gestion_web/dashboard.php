<?php
session_start();
require_once "config.php";

// Verificar sesión
if (!isset($_SESSION['cedula'])) {
    header("Location: usuarios/login.php");
    exit;
}

// Variables de sesión
$nombre = $_SESSION['nombre'] ?? 'Usuario';
$rol = $_SESSION['rol'] ?? 'Invitado';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Diseño general */
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f8;
        }
        .wrapper {
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 220px;
            background-color: #2c3e50;
            color: #fff;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            transition: 0.2s;
        }
        .sidebar a:hover {
            background-color: #34495e;
        }
        /* Main content */
        .main-content {
            flex: 1;
            padding: 30px;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 {
            font-size: 24px;
            color: #2c3e50;
        }
        header .logout {
            padding: 8px 15px;
            background-color: #e74c3c;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
        }
        header .logout:hover {
            background-color: #c0392b;
        }
        /* Tarjetas */
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .card {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .card h3 {
            margin-bottom: 15px;
            color: #2c3e50;
        }
        .card a {
            display: inline-block;
            padding: 8px 15px;
            background-color: #3498db;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
        }
        .card a:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Mi Panel</h2>
            <a href="dashboard.php">Inicio</a>
            <a href="usuarios/">Usuarios</a>
            <a href="productos/">Productos</a>
            <a href="categorias/">Categorías</a>
            <a href="proveedores/">Proveedores</a>
            <a href="audit_log/">Auditoría</a>
            <a href="usuarios/logout.php">Cerrar Sesión</a>
        </div>

        <!-- Contenido principal -->
        <div class="main-content">
            <header>
                <h1>Bienvenido, <?php echo htmlspecialchars($nombre); ?> (<?php echo htmlspecialchars($rol); ?>)</h1>
                <a href="usuarios/logout.php" class="logout">Cerrar Sesión</a>
            </header>

            <!-- Tarjetas de acceso rápido -->
            <div class="cards">
                <div class="card">
                    <h3>Usuarios</h3>
                    <a href="usuarios/">Ir</a>
                </div>
                <div class="card">
                    <h3>Productos</h3>
                    <a href="productos/">Ir</a>
                </div>
                <div class="card">
                    <h3>Categorías</h3>
                    <a href="categorias/">Ir</a>
                </div>
                <div class="card">
                    <h3>Proveedores</h3>
                    <a href="proveedores/">Ir</a>
                </div>
                <div class="card">
                    <h3>Auditoría</h3>
                    <a href="audit_log/">Ir</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
