<?php
session_start();
require_once "../config.php";

$mensaje = "";
$categorias = $pdo->query("SELECT * FROM categorias ORDER BY nombre_categoria")->fetchAll();
$proveedores = $pdo->query("SELECT * FROM proveedores ORDER BY nombre_proveedor")->fetchAll();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_producto'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $id_categoria = $_POST['id_categoria'];
    $id_proveedor = $_POST['id_proveedor'];
    $stock = $_POST['stock'];
    $usuario = $_SESSION['cedula'];

    try {
        // Insertar producto
        $stmt = $pdo->prepare("INSERT INTO productos (nombre_producto, descripcion, precio, id_categoria, id_proveedor)
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $descripcion, $precio, $id_categoria, $id_proveedor]);

        $id_producto = $pdo->lastInsertId();

        // Insertar inventario inicial
        $stmtInv = $pdo->prepare("INSERT INTO inventario (id_producto, stock, ultima_actualizacion)
                                  VALUES (?, ?, NOW())");
        $stmtInv->execute([$id_producto, $stock]);

        // Registrar auditoría
        $stmtAudit = $pdo->prepare("INSERT INTO audit_log (tabla, operacion, registro_id, usuario, descripcion)
                                    VALUES ('productos', 'INSERT', ?, ?, 'Producto agregado con stock inicial')");
        $stmtAudit->execute([$id_producto, $usuario]);

        header("Location: listar.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al agregar producto: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Agregar Producto</h1>
    <?php if($mensaje) echo "<p style='color:red;'>$mensaje</p>"; ?>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre_producto" required>
        <label>Descripción:</label>
        <textarea name="descripcion"></textarea>
        <label>Precio:</label>
        <input type="number" step="0.01" name="precio" required>
        <label>Categoría:</label>
        <select name="id_categoria" required>
            <?php foreach($categorias as $c): ?>
                <option value="<?= $c['id_categoria'] ?>"><?= htmlspecialchars($c['nombre_categoria']) ?></option>
            <?php endforeach; ?>
        </select>
        <label>Proveedor:</label>
        <select name="id_proveedor" required>
            <?php foreach($proveedores as $p): ?>
                <option value="<?= $p['id_proveedor'] ?>"><?= htmlspecialchars($p['nombre_proveedor']) ?></option>
            <?php endforeach; ?>
        </select>
        <label>Stock inicial:</label>
        <input type="number" name="stock" value="0" required>
        <button type="submit">Agregar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
