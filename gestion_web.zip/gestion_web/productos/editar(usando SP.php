<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_producto = $_GET['id'];
$usuario = $_SESSION['cedula'];
$mensaje = "";

// Obtener producto y stock
$stmt = $pdo->prepare("SELECT p.*, i.stock FROM productos p JOIN inventario i ON p.id_producto = i.id_producto WHERE p.id_producto = ?");
$stmt->execute([$id_producto]);
$producto = $stmt->fetch();

if (!$producto) die("Producto no encontrado.");

$categorias = $pdo->query("SELECT * FROM categorias ORDER BY nombre_categoria")->fetchAll();
$proveedores = $pdo->query("SELECT * FROM proveedores ORDER BY nombre_proveedor")->fetchAll();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_producto'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];

    try {
        // Llamar procedimiento almacenado
        $stmtSP = $pdo->prepare("CALL SP_ActualizarProducto(?, ?, ?, ?, ?)");
        $stmtSP->execute([$id_producto, $nombre, $precio, $stock, $usuario]);

        header("Location: listar.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al actualizar producto: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Editar Producto</h1>
    <?php if($mensaje) echo "<p style='color:red;'>$mensaje</p>"; ?>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre_producto" value="<?= htmlspecialchars($producto['nombre_producto']) ?>" required>
        <label>Precio:</label>
        <input type="number" step="0.01" name="precio" value="<?= $producto['precio'] ?>" required>
        <label>Stock:</label>
        <input type="number" name="stock" value="<?= $producto['stock'] ?>" required>
        <button type="submit">Actualizar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
