<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_producto = $_GET['id'];
$usuario = $_SESSION['cedula'];
$mensaje = "";

// Obtener producto y stock
$stmt = $pdo->prepare("
    SELECT p.*, i.stock 
    FROM productos p
    JOIN inventario i ON p.id_producto = i.id_producto
    WHERE p.id_producto = ?
");
$stmt->execute([$id_producto]);
$producto = $stmt->fetch();

if (!$producto) {
    die("Producto no encontrado.");
}

$categorias = $pdo->query("SELECT id_categoria, nombre_categoria FROM categorias")->fetchAll();
$proveedores = $pdo->query("SELECT id_proveedor, nombre_proveedor FROM proveedores")->fetchAll();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_producto'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $id_categoria = $_POST['id_categoria'];
    $id_proveedor = $_POST['id_proveedor'];
    $stock = $_POST['stock'];

    try {
        // Usar procedimiento almacenado para actualizar producto e inventario
        $stmtUpdate = $pdo->prepare("CALL SP_ActualizarProducto(?, ?, ?, ?, ?)");
        $stmtUpdate->execute([$id_producto, $nombre, $precio, $stock, $usuario]);

        // Actualizar descripción, categoría y proveedor
        $stmtExtra = $pdo->prepare("UPDATE productos SET descripcion=?, id_categoria=?, id_proveedor=? WHERE id_producto=?");
        $stmtExtra->execute([$descripcion, $id_categoria, $id_proveedor, $id_producto]);

        header("Location: listar.php");
        exit;

    } catch(PDOException $e) {
        $mensaje = "Error al actualizar producto: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Editar Producto</h1>
    <?php if($mensaje): ?>
        <p style="color:red;"><?= $mensaje ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Nombre Producto:</label>
        <input type="text" name="nombre_producto" value="<?= htmlspecialchars($producto['nombre_producto']) ?>" required>
        <label>Descripción:</label>
        <textarea name="descripcion"><?= htmlspecialchars($producto['descripcion']) ?></textarea>
        <label>Precio:</label>
        <input type="number" step="0.01" name="precio" value="<?= $producto['precio'] ?>" required>
        <label>Categoría:</label>
        <select name="id_categoria" required>
            <?php foreach($categorias as $c): ?>
                <option value="<?= $c['id_categoria'] ?>" <?= $c['id_categoria']==$producto['id_categoria']?'selected':'' ?>>
                    <?= htmlspecialchars($c['nombre_categoria']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <label>Proveedor:</label>
        <select name="id_proveedor" required>
            <?php foreach($proveedores as $p): ?>
                <option value="<?= $p['id_proveedor'] ?>" <?= $p['id_proveedor']==$producto['id_proveedor']?'selected':'' ?>>
                    <?= htmlspecialchars($p['nombre_proveedor']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <label>Stock:</label>
        <input type="number" name="stock" value="<?= $producto['stock'] ?>" required>
        <button type="submit">Actualizar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
