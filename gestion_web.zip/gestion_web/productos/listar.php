<?php
session_start();
require_once "../config.php";

if (!isset($_SESSION['cedula'])) {
    header("Location: ../usuarios/login.php");
    exit;
}

// Obtener productos con stock (vista)
$productos = $pdo->query("SELECT * FROM vw_productosinventario ORDER BY nombre_producto")->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Productos</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Lista de Productos</h1>
    <a href="agregar.php">Agregar Producto</a>
    <a href="../dashboard.php">Volver al Dashboard</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Última Actualización</th>
            <th>Acciones</th>
        </tr>
        <?php foreach($productos as $p): ?>
        <tr>
            <td><?= $p['id_producto'] ?></td>
            <td><?= htmlspecialchars($p['nombre_producto']) ?></td>
            <td>$<?= number_format($p['precio'],2) ?></td>
            <td><?= $p['stock'] ?></td>
            <td><?= $p['ultima_actualizacion'] ?></td>
            <td>
                <a href="editar.php?id=<?= $p['id_producto'] ?>">Editar</a> |
                <a href="eliminar.php?id=<?= $p['id_producto'] ?>" onclick="return confirm('¿Eliminar producto?')">Eliminar</a> |
                <a href="vender.php?id=<?= $p['id_producto'] ?>">Registrar Venta</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
