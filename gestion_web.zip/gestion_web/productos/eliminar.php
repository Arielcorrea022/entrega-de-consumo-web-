<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_producto = $_GET['id'];

// Eliminar producto e inventario
try {
    $pdo->beginTransaction();

    $pdo->prepare("DELETE FROM inventario_historico WHERE producto_id = ?")->execute([$id_producto]);
    $pdo->prepare("DELETE FROM inventario WHERE id_producto = ?")->execute([$id_producto]);
    $pdo->prepare("DELETE FROM productos WHERE id_producto = ?")->execute([$id_producto]);

    $pdo->commit();
    header("Location: listar.php");
    exit;

} catch(PDOException $e) {
    $pdo->rollBack();
    die("Error al eliminar producto: " . $e->getMessage());
}
?>
