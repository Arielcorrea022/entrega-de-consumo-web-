<?php
session_start();
require_once "../config.php";

if (!isset($_SESSION['cedula']) || $_SESSION['rol'] != "Administrador") {
    die("Acceso denegado.");
}

$usuarios = $pdo->query("SELECT u.cedula, u.nombre, u.correo, r.nombre_rol 
                         FROM usuarios u 
                         JOIN roles r ON u.id_rol = r.id_rol
                         ORDER BY u.nombre")->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios</title>
</head>
<body>
    <h1>Lista de Usuarios</h1>
    <a href="registro.php">Agregar Usuario</a>
    <a href="../dashboard.php">Volver al Dashboard</a>
    <table border="1">
        <tr>
            <th>Cédula</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
        <?php foreach($usuarios as $u): ?>
        <tr>
            <td><?= $u['cedula'] ?></td>
            <td><?= htmlspecialchars($u['nombre']) ?></td>
            <td><?= htmlspecialchars($u['correo']) ?></td>
            <td><?= htmlspecialchars($u['nombre_rol']) ?></td>
            <td>
                <a href="editar.php?cedula=<?= $u['cedula'] ?>">Editar</a> |
                <a href="eliminar.php?cedula=<?= $u['cedula'] ?>" onclick="return confirm('¿Eliminar usuario?')">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
