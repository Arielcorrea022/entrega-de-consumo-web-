<?php
session_start();
require_once "../config.php";

$mensaje = "";
$roles = $pdo->query("SELECT * FROM roles ORDER BY nombre_rol")->fetchAll();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);
    $id_rol = $_POST['id_rol'];

    try {
        $stmt = $pdo->prepare("INSERT INTO usuarios (cedula, nombre, correo, contraseña, id_rol)
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$cedula, $nombre, $correo, $contraseña, $id_rol]);

        // Registrar en auditoría
        $stmtAudit = $pdo->prepare("INSERT INTO audit_log (tabla, operacion, usuario, descripcion)
                                    VALUES ('usuarios', 'INSERT', ?, 'Registro de nuevo usuario')");
        $stmtAudit->execute([$cedula]);

        header("Location: login.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al registrar usuario: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
</head>
<body>
    <h1>Registrar Usuario</h1>
    <?php if($mensaje) echo "<p style='color:red;'>$mensaje</p>"; ?>
    <form method="POST">
        <label>Cédula:</label>
        <input type="text" name="cedula" required>
        <label>Nombre:</label>
        <input type="text" name="nombre" required>
        <label>Correo:</label>
        <input type="email" name="correo" required>
        <label>Contraseña:</label>
        <input type="password" name="contraseña" required>
        <label>Rol:</label>
        <select name="id_rol" required>
            <?php foreach($roles as $r): ?>
                <option value="<?= $r['id_rol'] ?>"><?= htmlspecialchars($r['nombre_rol']) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Registrar</button>
    </form>
    <p><a href="login.php">Volver al login</a></p>
</body>
</html>
