<?php
session_start();
require_once "../config.php";

if (isset($_SESSION['cedula'])) {
    $cedula = $_SESSION['cedula'];

    // Registrar logout en auditoría
    $stmtAudit = $pdo->prepare("INSERT INTO audit_log (tabla, operacion, usuario, descripcion)
                                VALUES ('usuarios', 'LOGOUT', ?, 'Cierre de sesión')");
    $stmtAudit->execute([$cedula]);
}

session_destroy();
header("Location: login.php");
exit;
?>
