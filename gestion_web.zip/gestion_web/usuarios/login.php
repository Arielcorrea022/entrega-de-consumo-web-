<?php
session_start();
require_once "../config.php";

// Si ya está logueado, redirigir al dashboard
if (isset($_SESSION['cedula'])) {
    header("Location: ../dashboard.php");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $password = $_POST['contraseña'];

    // Buscar usuario
    $stmt = $pdo->prepare("SELECT * FROM usuarios u JOIN roles r ON u.id_rol=r.id_rol WHERE correo = ?");
    $stmt->execute([$correo]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($password, $usuario['contraseña'])) {
        // Guardar sesión
        $_SESSION['cedula'] = $usuario['cedula'];
        $_SESSION['nombre'] = $usuario['nombre'];
        $_SESSION['rol'] = $usuario['nombre_rol'];

        // Registrar auditoría
        $stmtAudit = $pdo->prepare("INSERT INTO audit_log (tabla, operacion, usuario, descripcion)
                                    VALUES ('usuarios', 'LOGIN', ?, 'Inicio de sesión')");
        $stmtAudit->execute([$usuario['cedula']]);

        header("Location: ../dashboard.php");
        exit;
    } else {
        $error = "Correo o contraseña incorrecta";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            width: 350px;
        }
        .login-box h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
        }
        .login-box form label {
            font-weight: bold;
            margin-top: 10px;
        }
        .login-box form input[type="email"],
        .login-box form input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .login-box form button {
            margin-top: 20px;
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .login-box form button:hover {
            background-color: #2980b9;
        }
        .error {
            color: #e74c3c;
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Iniciar Sesión</h2>
        <form method="POST">
            <label>Correo:</label>
            <input type="email" name="correo" required>
            <label>Contraseña:</label>
            <input type="password" name="contraseña" required>
            <button type="submit">Ingresar</button>
            <?php if($error) echo "<p class='error'>$error</p>"; ?>
        </form>
    </div>
</body>
</html>
