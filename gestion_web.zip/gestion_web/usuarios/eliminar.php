<?php
session_start();
require_once "../config.php";

if (!isset($_GET['cedula'])) {
    header("Location: listar.php");
    exit;
}

$cedula = $_GET['cedula'];

// Eliminar usuario
$stmt = $pdo->prepare("DELETE FROM usuarios WHERE cedula = ?");
$stmt->execute([$cedula]);

header("Location: listar.php");
exit;
?>
