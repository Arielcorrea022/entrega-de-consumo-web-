<?php
session_start();
require_once "../config.php";

$mensaje = "";

// Obtener roles
$roles = $pdo->query("SELECT id_rol, nombre_rol FROM roles")->fetchAll();

// Obtener usuario por cédula
if (!isset($_GET['cedula'])) {
    header("Location: listar.php");
    exit;
}

$cedula = $_GET['cedula'];
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE cedula = ?");
$stmt->execute([$cedula]);
$usuario = $stmt->fetch();

if (!$usuario) {
    die("Usuario no encontrado.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $id_rol = $_POST['id_rol'];
    $contraseña = $_POST['contraseña'];

    if ($contraseña) {
        $contraseña = password_hash($contraseña, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, correo=?, contraseña=?, id_rol=? WHERE cedula=?");
        $stmt->execute([$nombre, $correo, $contraseña, $id_rol, $cedula]);
    } else {
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, correo=?, id_rol=? WHERE cedula=?");
        $stmt->execute([$nombre, $correo, $id_rol, $cedula]);
    }

    header("Location: listar.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Editar Usuario</h1>
    <?php if($mensaje): ?>
        <p style="color:red;"><?= $mensaje ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>
        <label>Correo:</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($usuario['correo']) ?>" required>
        <label>Contraseña (dejar vacío para no cambiar):</label>
        <input type="password" name="contraseña">
        <label>Rol:</label>
        <select name="id_rol" required>
            <?php foreach($roles as $r): ?>
                <option value="<?= $r['id_rol'] ?>" <?= $r['id_rol'] == $usuario['id_rol'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($r['nombre_rol']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Actualizar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
