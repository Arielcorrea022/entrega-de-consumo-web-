<?php
session_start();
require_once "config.php";

if (!isset($_SESSION['cedula']) || $_SESSION['rol'] != "Administrador") {
    die("Acceso denegado.");
}

$logs = $pdo->query("SELECT * FROM audit_log ORDER BY fecha DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Auditoría</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h1>Registro de Auditoría</h1>
    <a href="dashboard.php">Volver al Dashboard</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Tabla</th>
            <th>Operación</th>
            <th>Registro ID</th>
            <th>Usuario</th>
            <th>Fecha</th>
            <th>Descripción</th>
        </tr>
        <?php foreach($logs as $l): ?>
        <tr>
            <td><?= $l['log_id'] ?></td>
            <td><?= htmlspecialchars($l['tabla']) ?></td>
            <td><?= htmlspecialchars($l['operacion']) ?></td>
            <td><?= htmlspecialchars($l['registro_id']) ?></td>
            <td><?= htmlspecialchars($l['usuario']) ?></td>
            <td><?= $l['fecha'] ?></td>
            <td><?= htmlspecialchars($l['descripcion']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
