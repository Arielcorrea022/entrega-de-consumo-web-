<?php
require_once "config.php";

// Datos del administrador
$cedula = '1234567890';
$nombre = 'Admin';
$correo = 'admin@correo.com';
$contraseña = '1234'; // Contraseña que quieres asignar
$rol = 'Administrador';

try {
    // 1️⃣ Crear el rol si no existe
    $stmtRol = $pdo->prepare("SELECT id_rol FROM roles WHERE nombre_rol = ?");
    $stmtRol->execute([$rol]);
    $rolExistente = $stmtRol->fetch();

    if ($rolExistente) {
        $id_rol = $rolExistente['id_rol'];
    } else {
        $stmtInsertRol = $pdo->prepare("INSERT INTO roles (nombre_rol) VALUES (?)");
        $stmtInsertRol->execute([$rol]);
        $id_rol = $pdo->lastInsertId();
    }

    // 2️⃣ Verificar si el usuario ya existe
    $stmtUsuarioExistente = $pdo->prepare("SELECT * FROM usuarios WHERE cedula = ?");
    $stmtUsuarioExistente->execute([$cedula]);
    $usuarioExistente = $stmtUsuarioExistente->fetch();

    if ($usuarioExistente) {
        echo "El usuario con cédula $cedula ya existe. <br>";
        echo "Si quieres, puedes actualizar su contraseña para iniciar sesión correctamente.<br>";

        // 3️⃣ Actualizar contraseña si quieres
        $contraseña_segura = password_hash($contraseña, PASSWORD_DEFAULT);
        $stmtActualizar = $pdo->prepare("UPDATE usuarios SET contraseña = ?, id_rol = ? WHERE cedula = ?");
        $stmtActualizar->execute([$contraseña_segura, $id_rol, $cedula]);

        echo "Contraseña actualizada correctamente.<br>";
        echo "Correo: {$usuarioExistente['correo']}<br> Contraseña: $contraseña";
    } else {
        // 4️⃣ Crear usuario nuevo
        $contraseña_segura = password_hash($contraseña, PASSWORD_DEFAULT);

        $stmtUsuario = $pdo->prepare("INSERT INTO usuarios (cedula, nombre, correo, contraseña, id_rol) 
                                      VALUES (?, ?, ?, ?, ?)");
        $stmtUsuario->execute([$cedula, $nombre, $correo, $contraseña_segura, $id_rol]);

        echo "Usuario administrador creado correctamente.<br>";
        echo "Correo: $correo <br> Contraseña: $contraseña";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
