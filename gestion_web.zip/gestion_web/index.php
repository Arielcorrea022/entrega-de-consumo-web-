<?php
session_start();
require_once "config.php";

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cedula = $_POST['cedula'];
    $password = $_POST['contraseña'];

    // Consultar usuario
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE cedula = ?");
    $stmt->execute([$cedula]);
    $usuario = $stmt->fetch();

    if ($usuario) {
        // Verificar contraseña
        if (password_verify($password, $usuario['contraseña'])) {
            // Guardar sesión
            $_SESSION['cedula'] = $usuario['cedula'];
            $_SESSION['rol'] = $usuario['id_rol'];

            header("Location: dashboard.php");
            exit;
        } else {
            $mensaje = "Contraseña incorrecta.";
        }
    } else {
        $mensaje = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Gestión</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <h2>Iniciar sesión</h2>
        <?php if($mensaje): ?>
            <p style="color:red;"><?= $mensaje ?></p>
        <?php endif; ?>
        <form method="POST">
            <label>Cédula:</label>
            <input type="text" name="cedula" required>
            <label>Contraseña:</label>
            <input type="password" name="contraseña" required>
            <button type="submit">Ingresar</button>
        </form>
    </div>
</body>
</html>
