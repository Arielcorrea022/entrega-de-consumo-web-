<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_proveedor = $_GET['id'];

try {
    $stmt = $pdo->prepare("DELETE FROM proveedores WHERE id_proveedor = ?");
    $stmt->execute([$id_proveedor]);
    header("Location: listar.php");
    exit;
} catch(PDOException $e) {
    die("Error al eliminar proveedor: " . $e->getMessage());
}
?>
