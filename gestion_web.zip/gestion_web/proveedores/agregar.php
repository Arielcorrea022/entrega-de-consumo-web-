<?php
session_start();
require_once "../config.php";
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_proveedor'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];

    try {
        $stmt = $pdo->prepare("INSERT INTO proveedores (nombre_proveedor, telefono, correo, direccion)
                               VALUES (?, ?, ?, ?)");
        $stmt->execute([$nombre, $telefono, $correo, $direccion]);
        header("Location: listar.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al agregar proveedor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Proveedor</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Agregar Proveedor</h1>
    <?php if($mensaje): ?>
        <p style="color:red;"><?= $mensaje ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre_proveedor" required>
        <label>Teléfono:</label>
        <input type="text" name="telefono">
        <label>Correo:</label>
        <input type="email" name="correo">
        <label>Dirección:</label>
        <input type="text" name="direccion">
        <button type="submit">Agregar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
