<?php
session_start();
require_once "../config.php";

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id_proveedor = $_GET['id'];
$mensaje = "";

$stmt = $pdo->prepare("SELECT * FROM proveedores WHERE id_proveedor = ?");
$stmt->execute([$id_proveedor]);
$proveedor = $stmt->fetch();

if (!$proveedor) die("Proveedor no encontrado.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_proveedor'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];

    try {
        $stmt = $pdo->prepare("UPDATE proveedores SET nombre_proveedor=?, telefono=?, correo=?, direccion=? WHERE id_proveedor=?");
        $stmt->execute([$nombre, $telefono, $correo, $direccion, $id_proveedor]);
        header("Location: listar.php");
        exit;
    } catch(PDOException $e) {
        $mensaje = "Error al actualizar proveedor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Proveedor</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Editar Proveedor</h1>
    <?php if($mensaje): ?>
        <p style="color:red;"><?= $mensaje ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre_proveedor" value="<?= htmlspecialchars($proveedor['nombre_proveedor']) ?>" required>
        <label>Teléfono:</label>
        <input type="text" name="telefono" value="<?= htmlspecialchars($proveedor['telefono']) ?>">
        <label>Correo:</label>
        <input type="email" name="correo" value="<?= htmlspecialchars($proveedor['correo']) ?>">
        <label>Dirección:</label>
        <input type="text" name="direccion" value="<?= htmlspecialchars($proveedor['direccion']) ?>">
        <button type="submit">Actualizar</button>
    </form>
   
