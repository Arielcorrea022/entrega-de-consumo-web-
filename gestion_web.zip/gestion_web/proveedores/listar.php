<?php
session_start();
require_once "../config.php";

if (!isset($_SESSION['cedula'])) {
    header("Location: ../index.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM proveedores ORDER BY nombre_proveedor ASC");
$proveedores = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Proveedores</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Lista de Proveedores</h1>
    <a href="agregar.php">Agregar Proveedor</a>
    <a href="../dashboard.php">Volver al Dashboard</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Correo</th>
            <th>Dirección</th>
            <th>Acciones</th>
        </tr>
        <?php foreach($proveedores as $p): ?>
        <tr>
            <td><?= $p['id_proveedor'] ?></td>
            <td><?= htmlspecialchars($p['nombre_proveedor']) ?></td>
            <td><?= htmlspecialchars($p['telefono']) ?></td>
            <td><?= htmlspecialchars($p['correo']) ?></td>
            <td><?= htmlspecialchars($p['direccion']) ?></td>
            <td>
                <a href="editar.php?id=<?= $p['id_proveedor'] ?>">Editar</a> |
                <a href="eliminar.php?id=<?= $p['id_proveedor'] ?>" onclick="return confirm('¿Eliminar proveedor?')">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
